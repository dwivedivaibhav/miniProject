package com.cg.uas.bean;

public class ProgramLocationBean 
{
	private int scheduledProgId;
	private String city;
	private String state;
	private int zipcode;
	private String location;
	public ProgramLocationBean(int scheduledProgId, String city, String state,
			int zipcode, String location) {
		super();
		this.scheduledProgId = scheduledProgId;
		this.city = city;
		this.state = state;
		this.zipcode = zipcode;
		this.location = location;
	}
	public ProgramLocationBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getScheduledProgId() {
		return scheduledProgId;
	}
	public void setScheduledProgId(int scheduledProgId) {
		this.scheduledProgId = scheduledProgId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getZipcode() {
		return zipcode;
	}
	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	@Override
	public String toString() {
		return "ProgramLocationBean [scheduledProgId=" + scheduledProgId
				+ ", city=" + city + ", state=" + state + ", zipcode="
				+ zipcode + ", location=" + location + "]";
	}
	
	
}
