package com.cg.uas.service;

import java.util.ArrayList;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.LoginBean;
import com.cg.uas.bean.ProgramScheduledBean;
import com.cg.uas.dao.UasDao;
import com.cg.uas.dao.UasDaoImpl;
import com.cg.uas.exception.UniversityException;

public class UasServiceImpl implements UasService{

	UasDao uasDao = null;
	public UasServiceImpl() {
		uasDao = new UasDaoImpl();
	}
	@Override
	public ArrayList<String> getProgramsScheduled() throws UniversityException {
		
		return uasDao.getProgramsScheduled();
	}
	@Override
	public int setNewApplicant(ApplicantBean app) throws UniversityException {
		
		return uasDao.setNewApplicant(app);
	}
	@Override
	public ArrayList<LoginBean> getLoginDetails(LoginBean login)
			throws UniversityException
			{
		
		return uasDao.getLoginDetails(login);
	}
	@Override
	public int addProgramScheduled(ProgramScheduledBean ps)
			throws UniversityException {
		
		return uasDao.addProgramScheduled(ps);
	}
	@Override
	public int deleteProgramScheduled(int scheduledProgId)
			throws UniversityException {
		
		return uasDao.deleteProgramScheduled(scheduledProgId);
	}

}
