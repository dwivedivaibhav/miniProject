package com.cg.uas.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;




import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.LoginBean;
import com.cg.uas.bean.ProgramScheduledBean;
import com.cg.uas.exception.UniversityException;
import com.cg.uas.util.DBUtil;

public class UasDaoImpl implements UasDao {

	Connection conn = null;
	PreparedStatement pst = null;
	Statement st = null;
	ResultSet rs = null;

	//returns programs_scheduled record
	@Override
	public ArrayList<String> getProgramsScheduled() throws UniversityException {

		String selProgSch = "SELECT * FROM programs_scheduled";
		ArrayList<String> progSchList = new ArrayList<String>();

		try {

			conn = DBUtil.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(selProgSch);

			while(rs.next()) {

				progSchList.add(rs.getString("program_name"));

			}
		} 
		catch (Exception e) {
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				st.close();
				rs.close();
			}
			catch(Exception e){
				throw new UniversityException(e.getMessage());
			}
		}

		return progSchList;
	}

	//inserting new applicant
	@Override
	public int setNewApplicant(ApplicantBean app) throws UniversityException {
		String insQry = "INSERT INTO application values(?,?,?,?,?,?,?,?,?,?)";
		int dataAdded = 0;
		try {
			conn = DBUtil.getConnection();
			st = conn.createStatement();
			pst = conn.prepareStatement(insQry);
			
			LocalDate bDate=app.getDateOfBirth();
			Date dob=Date.valueOf(bDate);
			pst.setInt(1,generateAppId());
			pst.setString(2, app.getFullName());
			pst.setDate(3, Date.valueOf(app.getDateOfBirth()));
			pst.setString(4, app.getQualification());
			pst.setFloat(5, app.getMarks());
			pst.setString(6, app.getGoals());
			pst.setString(7, app.getEmail());
			pst.setInt(8, app.getScheduledProgId());
			pst.setString(9, app.getStatus());
			pst.setDate(10, app.getInterviewDate());
			
			dataAdded = pst.executeUpdate();
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				st.close();
				rs.close();
			}
			catch(Exception e){
				throw new UniversityException(e.getMessage());
			}
		}

		return dataAdded;
	}

	private int generateAppId() throws UniversityException {
		String qry = "SELECT appliaction_id_seq.NEXTVAL FROM DUAL";
		int generateValue;
		
		try {
			conn = DBUtil.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(qry);
			
			rs.next();
			generateValue = rs.getInt(1);
		} 
		catch (Exception e) {
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				st.close();
				rs.close();
			}
			catch(Exception e){
				throw new UniversityException(e.getMessage());
			}
		}

		return generateValue;
	}

	@Override
	public ArrayList<LoginBean> getLoginDetails(LoginBean login) throws UniversityException
	{
		String selLogin = "SELECT login_id,password  FROM users WHERE role=?";
		ArrayList<LoginBean> loginList = new ArrayList<LoginBean>();
		
		try
		{
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(selLogin);
			pst.setString(1,login.getRole());
			pst.executeQuery();
			
			while(rs.next()) {

				login=new LoginBean(rs.getString("loginId"),
						rs.getString("password"),
						rs.getString("role"));
				loginList.add(login);

			}
		} 
		catch (Exception e) {
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				st.close();
				rs.close();
			}
			catch(Exception e){
				throw new UniversityException(e.getMessage());
			}
		}

		return loginList;
		
	}

	@Override
	public int addProgramScheduled(ProgramScheduledBean ps)
			throws UniversityException
	{
		String addQry = "INSERT INTO Programs_Scheduled values(?,?,?,?,?,?)";
		int dataAdd = 0;
		try {
			conn = DBUtil.getConnection();
			st = conn.createStatement();
			pst = conn.prepareStatement(addQry);
			
			LocalDate startDate=ps.getStartDate();
			Date sDate=Date.valueOf(startDate);
			LocalDate endDate=ps.getEndDate();
			Date eDate=Date.valueOf(endDate);
			
			pst.setInt(1,generateScheduledProgId());
			pst.setString(2, ps.getProgramName());
			pst.setString(3, ps.getLocation());
			pst.setDate(4, sDate);
			pst.setDate(5, eDate);
			pst.setInt(6, ps.getSessionPerWeek());
			
			
			dataAdd = pst.executeUpdate();
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				st.close();
				rs.close();
			}
			catch(Exception e){
				throw new UniversityException(e.getMessage());
			}
		}

		return dataAdd;
	}

	@Override
	public int deleteProgramScheduled(int scheduledProgId )
			throws UniversityException
	{
		
		String deleteQry="delete from Programs_Scheduled where scheduledProgId=?";
		int dataDeleted=0;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(deleteQry);
			pst.setInt(1,scheduledProgId);
			dataDeleted=pst.executeUpdate();
			
		} 
		
		catch (Exception e)
		{
			throw new UniversityException(e.getMessage());
		
		} 
		finally
		{
			try {
				pst.close();
				conn.close();
			} 
			catch (SQLException e) 
			{
				throw new UniversityException(e.getMessage());
				
			}
			
		}
		
		return dataDeleted;
		
	}
	private int generateScheduledProgId() throws UniversityException {
		String qry = "SELECT SCHEDULED_PGM_SEQ NEXTVAL FROM DUAL";
		int generateValued;
		
		try {
			conn = DBUtil.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(qry);
			
			rs.next();
			generateValued = rs.getInt(1);
		} 
		catch (Exception e) {
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				st.close();
				rs.close();
			}
			catch(Exception e){
				throw new UniversityException(e.getMessage());
			}
		}

		return generateValued;
	}

}
