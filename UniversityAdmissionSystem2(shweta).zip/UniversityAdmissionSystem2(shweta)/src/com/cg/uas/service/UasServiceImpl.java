package com.cg.uas.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.LoginBean;
import com.cg.uas.bean.ProgramScheduledBean;
import com.cg.uas.dao.UasDao;
import com.cg.uas.dao.UasDaoImpl;
import com.cg.uas.exception.UniversityException;

public class UasServiceImpl implements UasService{

	UasDao uasDao = null;
	public UasServiceImpl() {
		uasDao = new UasDaoImpl();
	}
	@Override
	public ArrayList<String> getProgramsScheduled() throws UniversityException {
		
		return uasDao.getProgramsScheduled();
	}
	@Override
	public int setNewApplicant(ApplicantBean app) throws UniversityException {
		
		return uasDao.setNewApplicant(app);
	}
	@Override
	public ArrayList<LoginBean> getLoginDetails(LoginBean login)
			throws UniversityException
			{
		
		return uasDao.getLoginDetails(login);
	}
	@Override
	public int addProgramScheduled(ProgramScheduledBean ps)
			throws UniversityException {
		
		return uasDao.addProgramScheduled(ps);
	}
	@Override
	public int deleteProgramScheduled(int scheduledProgId)
			throws UniversityException {
		
		return uasDao.deleteProgramScheduled(scheduledProgId);
	}

	@Override
	public boolean isValid(ProgramScheduledBean prog)throws UniversityException {
		
		String pname = prog.getProgramName();
		String loc = prog.getLocation();
		LocalDate startdate=prog.getStartDate();
		int session = prog.getSessionPerWeek();
	
		String nameRegex = "[A-Z][a-z]+";
		String locRegex = "[A-Z][a-z]+";
		
		if( !Pattern.matches(nameRegex, pname) ) {
			throw new UniversityException("Program Name Should Start With Capital (For Eg: Java)");
			
		}
		else if( !Pattern.matches(locRegex, loc)) {
			throw new UniversityException("Location Should Start With Capital (For Eg: Pune)");
		}
		else if( session<0 && session>6 ) {
			throw new UniversityException("Please Enter A Valid Session");
		}
		
		else  
		{
			return true;
		}
		
		
	}
	@Override
	public boolean isValid(ApplicantBean app)throws UniversityException {
		
		String fname = app.getFullName();
		String qualify = app.getQualification();
		float marks= app.getMarks();
		String email=app.getEmail();
		LocalDate birthdate=app.getDateOfBirth();
		String goals=app.getGoals();
		
		
		String fnameRegex = "[A-Z][a-z]+";
		String quaRegex = "[A-Z][a-z]+";
		String goal= "[A-Z][a-z]+";
		String mail="[A-Za-z0-9+_.-]+@(.+)$";
		
		
		if( !Pattern.matches(fnameRegex, fname) ) {
			throw new UniversityException("Applicant Name Should Start With Capital (For Eg: Java)");
			
		}
		else if( !Pattern.matches(quaRegex, qualify)) {
			throw new UniversityException("Qualification Should Start With Capital (For Eg: Pune)");
		}
		else if( !Pattern.matches(goal, goals)) {
			throw new UniversityException("Goals Should Start With Capital");
		}
		else if( marks<0 && marks>100 ) {
			throw new UniversityException("Please Enter A Valid Marks");
		}
		if( !Pattern.matches(mail, email) ) {
			throw new UniversityException("Please Enter a Valid email id");
			
		}
		
		else  
		{
			return true;
		}
		
		
	}
}
