package com.cg.uas.service;

import java.util.ArrayList;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.LoginBean;
import com.cg.uas.bean.ProgramScheduledBean;
import com.cg.uas.exception.UniversityException;

public interface UasService {

	public ArrayList<String> getProgramsScheduled() throws UniversityException;
	public int setNewApplicant(ApplicantBean app) throws UniversityException;
	public ArrayList<LoginBean> getLoginDetails(LoginBean login) throws UniversityException;
	public int addProgramScheduled(ProgramScheduledBean ps) throws UniversityException;
	public int deleteProgramScheduled(int scheduledProgId) throws UniversityException;
	public boolean isValid(ProgramScheduledBean prog)throws UniversityException;
	public boolean isValid(ApplicantBean app)throws UniversityException;
}
