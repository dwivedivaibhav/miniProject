package com.cg.uas.ui;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Scanner;




import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramScheduledBean;
import com.cg.uas.exception.UniversityException;
import com.cg.uas.service.UasService;
import com.cg.uas.service.UasServiceImpl;

public class UasClient 
{

	static Scanner sc = null;
	static UasService uasSer= null;
	static ApplicantBean appBean = null;
	
	public static void main(String [] args)
	{
		
		sc = new Scanner(System.in);
		uasSer = new UasServiceImpl();
		
		
		
		while(true) {
			System.out.println("**************************");
			System.out.println("University Admission System");
			System.out.println("**************************");
			
//			int choice = 0;
			System.out.println("1. New Application");
			System.out.println("2. Mac");
			System.out.println("3. Administrator");
			System.out.println("4. Exit");
			
			System.out.println("Enter your choice");
			int choice = sc.nextInt();
			
			System.out.println(choice);
			
			switch(choice) {
			case 1: newApplicant();
			break;
			case 2: mac();
			break;
			case 3: admin();
			break;
			case 4: exit();
			break;
			default:
				System.out.println("Invalid Input");
			}
		}
	}

	private static void newApplicant() {
		int choice = 0;
		
		System.out.println("Program Scheduled");
		ArrayList progList = new ArrayList<>();
		try {
			int i = 1;
			progList = uasSer.getProgramsScheduled();
			Iterator it = progList.iterator();
			while(it.hasNext()) {
				System.out.println(i++ + " " + it.next());
			}
			System.out.println("Enter your choice");
			choice = sc.nextInt();
			
			setApplicationBean(choice);
		}
		catch (UniversityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private static void setApplicationBean(int choice) {
		
		/*System.out.println("Enter your Full Name");
		String name = sc.next();
		System.out.println("Enter Date of Birth in format yyyy-mm-dd");
		String date = sc.next();
		System.out.println("Enter Highest Qualification");
		String qua = sc.next();
		System.out.println("Enter Marks Obtained");
		Float marks = sc.nextFloat();
		System.out.println("Enter Goals");
		String goals = sc.next();
		System.out.println("Enter Email Id");
		String email = sc.next();
		
		String status = "Applied";
		String interviewDate = null;
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		Date date2=null;
		date2 = dateFormat.parse(date);
		
		ApplicantBean appBean = new ApplicantBean(name, date2, marks, qua, email, choice, status,interviewDate);
		*/
	}

	private static void mac()
	{
		// TODO Auto-generated method stub
		
	}

	private static void admin() 
	{
		System.out.println("Enter username:");
		String loginId=sc.next();
		System.out.println("Enter password:");
		String pwd=sc.next();
		if(loginId.equals("admin") && pwd.equals("admin"))
			{
				int option=0;
				System.out.println("1. Add details");
				System.out.println("2. Delete ");
				System.out.println("3. Exit");
				System.out.println("Enter your option");
				option = sc.nextInt();
				
				
				try
				{
					switch(option)
					{
						case 1: add();
						break;
						case 2: delete();
						break;
						default:System.out.println("Invalid Input");
					
					}
				}
				catch (Exception e) 
				{
					System.out.println(e.getMessage());
					//e.printStackTrace();
				}
			}
			else
			{
				System.out.println("Invalid Username and Password");
			}

		
	}
	private static void delete() 
	{
		System.out.println("Enter ur id which is to be deleted");
		int sid=sc.nextInt();
		
		try
		{
			int dataDeleted = uasSer.deleteProgramScheduled(sid);
			if(dataDeleted==1)
			{
				System.out.println("Scheduled program id deleted");
			}
			else
			{
				System.out.println("may have some exception deletion");
			}
			
		} 
		catch (UniversityException e)
		{
			System.out.println(e.getMessage());
			//e.printStackTrace();
		}
		
	}

	private static void add() 
	{
		
		//System.out.println("Enter Scheduled program id:");
		//int id = sc.nextInt();
		System.out.println("Enter program name:");
		String pname = sc.next();
		System.out.println("Enter location:");
		String loc = sc.next();
		System.out.println("Enter start date:");
		String sdate = sc.next();
		System.out.println("Enter end date:");
		String edate = sc.next();
		System.out.println("Enter session per week:");
		int session = sc.nextInt();
		
		LocalDate startDate=LocalDate.parse(sdate);
		
		LocalDate endDate=LocalDate.parse(edate);
		
		ProgramScheduledBean ps = new ProgramScheduledBean(pname,loc,startDate,endDate,session);
		try {
			int id1=uasSer.addProgramScheduled(ps);
			if(id1>0)
			{
				System.out.println("Data successfully added");
			}
		}
		catch (UniversityException e) {
			System.out.println(e.getMessage());
		}
	}

	private static void exit() {
		// TODO Auto-generated method stub
		
	}
}
