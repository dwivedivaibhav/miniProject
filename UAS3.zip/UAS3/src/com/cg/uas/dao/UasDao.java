package com.cg.uas.dao;

import java.util.ArrayList;

import com.cg.uas.bean.AdministratorBean;
import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.UsersBean;
import com.cg.uas.exception.UniversityException;

public interface UasDao {
	
	public ArrayList<String> getProgramsScheduled() throws UniversityException;
	
	public int setNewApplicant(ApplicantBean app) throws UniversityException;
	
	public int addProgramsOffered(AdministratorBean admin) throws UniversityException;
	
	public int updateProgramsOffered(AdministratorBean admin) throws UniversityException;
	
	public int deleteProgramsOffered(String admin) throws UniversityException;
	
	public ArrayList<UsersBean> loginAdmin(String user) throws UniversityException;
}
