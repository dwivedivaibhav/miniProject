package com.cg.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.uas.bean.AdministratorBean;
import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.UsersBean;
import com.cg.uas.exception.UniversityException;
import com.cg.uas.util.DBUtil;


public class UasDaoImpl implements UasDao {

	Connection conn = null;
	PreparedStatement pst = null;
	Statement st = null;
	ResultSet rs = null;
	
	
	@Override
	public ArrayList<String> getProgramsScheduled() throws UniversityException 
	{
		String selProgSch = "SELECT * FROM programs_scheduled";
		ArrayList<String> progSchList = new ArrayList<String>();

		try {

			conn = DBUtil.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(selProgSch);

			while(rs.next()) {

				progSchList.add(rs.getString("program_name"));

			}
		} 
		catch (Exception e) {
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				st.close();
				rs.close();
			}
			catch(Exception e){
				throw new UniversityException(e.getMessage());
			}
		}

		return progSchList;
	}
		
	private int generateAppId() throws UniversityException 
	{
		String qry = "SELECT appliaction_id_seq.NEXTVAL FROM DUAL";
		int generateValue;
		
		try {
			conn = DBUtil.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(qry);
			
			rs.next();
			generateValue = rs.getInt(1);
		} 
		catch (Exception e) {
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				st.close();
				rs.close();
			}
			catch(Exception e){
				throw new UniversityException(e.getMessage());
			}
		}

		return generateValue;
	}		
	
	
	@Override
	public int setNewApplicant(ApplicantBean app) throws UniversityException {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public int addProgramsOffered(AdministratorBean admin)
			throws UniversityException {
		String insertQry = "insert into Programs_Offered"
				+ "(program_name, description, applicant_eligibility, duration, "
				+ "degree_certificate_offered) values(?, ?, ?, ?, ?)";
		
		int dataAdded = 0;
		
		try
		{
			conn = DBUtil.getConnection();
			
			pst = conn.prepareStatement(insertQry);
			
			pst.setString(1, admin.getProgramName());
			
			pst.setString(2, admin.getDescription());
			
			pst.setString(3, admin.getEligibility());
			
			pst.setInt(4, admin.getDuration());
			
			pst.setString(5, admin.getDegreeCertOffered());
			
			dataAdded = pst.executeUpdate();
			
//			System.out.println("Program Inserted into the Table"
//					+ " Programs Offered");
		}
		
		catch (Exception e)
		{
			throw new UniversityException(e.getMessage());
		}
		
		finally
		{
			try
			{
				conn.close();
				
				pst.close();
			}
			
			catch (SQLException se)
			{
				throw new UniversityException(se.getMessage());
			}
		}
		
		return dataAdded;
		 
	}
	
	@Override
	public int updateProgramsOffered(AdministratorBean admin)
			throws UniversityException {
		String qry = "update Programs_Offered set description=?,"
				+ "applicant_eligibility=?, duration=?, "
				+ "degree_certificate_offered=?"
				+ " where program_name=?";
		
		int dataUpdated = 0;
		//AdministratorBean admin1=new AdministratorBean();		
		try
		{
			conn = DBUtil.getConnection();
			
			pst = conn.prepareStatement(qry);
			
			pst.setString(1, admin.getDescription());
			
			pst.setString(2, admin.getEligibility());
			
			pst.setInt(3, admin.getDuration());
			
			pst.setString(4, admin.getDegreeCertOffered());
			
			pst.setString(5, admin.getProgramName());
			
			dataUpdated = pst.executeUpdate();
			
//			System.out.println("Programs offered Table is updated");
		}
		
		catch (Exception e)
		{
			throw new UniversityException(e.getMessage());
		}
		
		finally
		{
			try {
				conn.close();
				
				pst.close();
			} 
			
			catch (SQLException se) {
				// TODO: handle exception
				
				throw new UniversityException(se.getMessage());
			}
		}
		
		return dataUpdated;
	}
	
	
	
	
	
	@Override
	public int deleteProgramsOffered(String admin) throws UniversityException {
		String qry = "Delete from Programs_Offered where program_name = ?";
		
		int dataDeleted = 0;
		
		try
		{
			
			conn = DBUtil.getConnection();
			
			pst = conn.prepareStatement(qry);
			
			pst.setString(1, admin);
			
			dataDeleted = pst.executeUpdate();
			
		}
		
		catch (Exception e)
		{
		
			throw new UniversityException(e.getMessage());
		}
		
		finally
		{
			try
			{
				conn.close();
				
				pst.close();
			}
			
			catch (SQLException se)
			{
			
				throw new UniversityException(se.getMessage());
			}
		}
		
		return dataDeleted;
	}
	
	
	@Override
	public ArrayList<UsersBean> loginAdmin(String user)
			throws UniversityException {
		// TODO Auto-generated method stub
		return null;
	}

	

}
