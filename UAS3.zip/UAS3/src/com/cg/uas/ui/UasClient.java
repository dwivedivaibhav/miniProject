package com.cg.uas.ui;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.uas.bean.AdministratorBean;
import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.exception.UniversityException;
import com.cg.uas.service.UasService;
import com.cg.uas.service.UasServiceImpl;

public class UasClient {

	static Scanner sc = null;
	static UasService uasSer= null;
	static ApplicantBean appBean = null;
	
	public static void main(String [] args){
		
		sc = new Scanner(System.in);
		uasSer = new UasServiceImpl();
		
		
		while(true) {
			System.out.println("**************************");
			System.out.println("University Admission System");
			System.out.println("**************************");
			
			int choice = 0;
			System.out.println("1. New Application");
			System.out.println("2. Mac");
			System.out.println("3. Administrator");
			System.out.println("4. Exit");
			System.out.println("Enter your choice");
			
			choice = sc.nextInt();
			
			switch(choice) {
			case 1: newApplicant();
			break;
			case 2: mac();
			break;
			case 3: admin();
			break;
			case 4: exit();
			break;
			default:
				System.out.println("Invalid Input");
			}
		}
	}

	private static void newApplicant() {
		int choice = 0;
		
		System.out.println("Program Scheduled");
		ArrayList progList = new ArrayList<>();
		try {
			int i = 1;
			progList = uasSer.getProgramsScheduled();
			Iterator it = progList.iterator();
			while(it.hasNext()) {
				System.out.println(i++ + " " + it.next());
			}
			System.out.println("Enter your choice");
			choice = sc.nextInt();
			
			setApplicationBean(choice);
		}
		catch (UniversityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private static void setApplicationBean(int choice) {
		
		System.out.println("Enter your Full Name");
		String name = sc.next();
		System.out.println("Enter Date of Birth in format yyyy-mm-dd");
		String date = sc.next();
		System.out.println("Enter Highest Qualification");
		String qua = sc.next();
		System.out.println("Enter Marks Obtained");
		Float marks = sc.nextFloat();
		System.out.println("Enter Goals");
		String goals = sc.next();
		System.out.println("Enter Email Id");
		String email = sc.next();
		
		String status = "Applied";
		String interviewDate = null;
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		Date date2=null;
			// date2 = dateFormat.parse(date);
		
			// appBean = new ApplicantBean(name, date2, marks, qua, email, choice, status,interviewDate);
		
	}

	private static void mac() {
		// TODO Auto-generated method stub
		
	}

	private static void admin() {
		int choice = 0;
		System.out.println("Functions You Want To Perform:");
		System.out.println("*************************");
		
		System.out.println("1. Add Program");
		System.out.println("2. Update Program");
		System.out.println("3. Delete Program");
		System.out.println("4. Exit");
		
		
		choice = sc.nextInt();
		switch (choice)
		{
		case 1:
			addPrograms();
			break;
			
		case 2:
			updatePrograms();
			break;
			
		case 3:
			deletePrograms();
			break;
			
		case 4:
			System.exit(0);
			break;
			
		default:
			System.out.println("Invalid Input Given");	
		}
	}
	
	//Delete Id
	private static void deletePrograms() 
	{
		System.out.println("Enter your Program Name which is to be deleted");
		String admin=sc.next();
		
		try
		{
			int dataDeleted = uasSer.deleteProgramsOffered(admin);
			if(dataDeleted==1)
			{
				System.out.println("Scheduled program deleted");
			}
			else
			{
				System.out.println("Program Name Is Not Present");
			}
			
		} 
		catch (UniversityException e)
		{
			System.out.println(e.getMessage());
			//e.printStackTrace();
		}
		
	}
		

	
	//Update
	private static void updatePrograms() 
	{
		System.out.println("Enter Program Name You Want To Update: ");
		String programname= sc.next();
		
		System.out.println("Enter Description : ");
		String programdesc = sc.next();
		
		System.out.println("Enter the eligibilty : ");
		String programelig = sc.next();
		
		System.out.println("Enter the duration : ");
		int programdur = sc.nextInt();
		
		System.out.println("Enter if the certificate "
				+ "is offered of the program : ");
		String programcert = sc.next();
		
		try
		{
			AdministratorBean adminBean = new AdministratorBean();
		
			adminBean.setProgramName(programname);
			adminBean.setDescription(programdesc);
			adminBean.setEligibility(programelig);
			adminBean.setDuration(programdur);
			adminBean.setDegreeCertOffered(programcert);
		
			int dataUpdated = uasSer.updateProgramsOffered(adminBean);
			
			if (dataUpdated == 1)
			{
				System.out.println("Programs Added into the Table");
			}
			
			else
			{
				System.out.println("Maybe some error occurred "
						+ "during the addition of the program");
			}
		}
		
		catch (UniversityException ue)
		{
			System.out.println(ue.getMessage());
		}
		
	}
	

	public static void addPrograms(){
		System.out.println("Enter Program Name : ");
		String pname = sc.next();
		
		System.out.println("Enter Description : ");
		String pdesc = sc.next();
		
		System.out.println("Enter the eligibilty : ");
		String pelig = sc.next();
		
		System.out.println("Enter the duration : ");
		int pdur = sc.nextInt();
		
		System.out.println("Enter if the certificate "
				+ "is offered of the program : ");
		String pcert = sc.next();
		
		try
		{
			AdministratorBean adminBean = new AdministratorBean();
		
			adminBean.setProgramName(pname);
			adminBean.setDescription(pdesc);
			adminBean.setEligibility(pelig);
			adminBean.setDuration(pdur);
			adminBean.setDegreeCertOffered(pcert);
		
			int dataAdded = uasSer.addProgramsOffered(adminBean);
			
			if (dataAdded == 1)
			{
				System.out.println("Programs Added into the Table");
			}
			
			else
			{
				System.out.println("Maybe some error occurred "
						+ "during the addition of the program");
			}
		}
		
		catch (UniversityException ue)
		{
			System.out.println(ue.getMessage());
		}
		
	}

	private static void exit() {
		// TODO Auto-generated method stub
		
	}
}
