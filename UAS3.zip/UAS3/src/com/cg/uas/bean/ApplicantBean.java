package com.cg.uas.bean;

import java.sql.Date;

public class ApplicantBean {

	private	String fullName;
	private Date dateOfBirth;
	private String qualification;
	private float marks;
	private String goals;
	private String email;
	@Override
	public String toString() {
		return "ApplicantBean [fullName=" + fullName + ", dateOfBirth="
				+ dateOfBirth + ", qualification=" + qualification + ", marks=" + marks + ", goals=" + goals
				+ ", email=" + email + ", scheduledProgId=" + scheduledProgId + ", status=" + status
				+ ", interviewDate=" + interviewDate + "]";
	}
	public ApplicantBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	private int scheduledProgId;
	private String status;
	private Date interviewDate;
	public ApplicantBean(String fullName, Date dateOfBirth, String qualification, float marks,
			String goals, String email, int scheduledProgId, String status, Date interviewDate) {
		super();
		
		this.fullName = fullName;
		this.dateOfBirth = dateOfBirth;
		this.qualification = qualification;
		this.marks = marks;
		this.goals = goals;
		this.email = email;
		this.scheduledProgId = scheduledProgId;
		this.status = status;
		this.interviewDate = interviewDate;
	}
	
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public float getMarks() {
		return marks;
	}
	public void setMarks(float marks) {
		this.marks = marks;
	}
	public String getGoals() {
		return goals;
	}
	public void setGoals(String goals) {
		this.goals = goals;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getScheduledProgId() {
		return scheduledProgId;
	}
	public void setScheduledProgId(int scheduledProgId) {
		this.scheduledProgId = scheduledProgId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getInterviewDate() {
		return interviewDate;
	}
	public void setInterviewDate(Date interviewDate) {
		this.interviewDate = interviewDate;
	}
	
}

