package com.cg.uas.service;

import java.util.ArrayList;

import javax.swing.text.StyledEditorKit.BoldAction;

import com.cg.uas.bean.AdministratorBean;
import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.UsersBean;
import com.cg.uas.exception.UniversityException;

public interface UasService {

	public ArrayList<String> getProgramsScheduled() throws UniversityException;
	
	public int setNewApplicant(ApplicantBean app) throws UniversityException;
	
	public int addProgramsOffered(AdministratorBean admin) throws UniversityException;
	
	public int updateProgramsOffered(AdministratorBean admin) throws UniversityException;
	
	public int deleteProgramsOffered(String admin) throws UniversityException;
	
	public ArrayList<UsersBean> loginAdmin(String user) throws UniversityException;
	
	public boolean matchCredentials(String lgnid, String pswd, String roles) throws UniversityException;

	int deleteProgramsOffered(int admin) throws UniversityException;
	
	public boolean isValid(AdministratorBean applicant) throws UniversityException;

}
