package com.cg.uas.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.uas.bean.AdministratorBean;
import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.UsersBean;
import com.cg.uas.dao.UasDao;
import com.cg.uas.dao.UasDaoImpl;
import com.cg.uas.exception.UniversityException;

public class UasServiceImpl implements UasService{

	UasDao uasDao = null;
	UsersBean users = null;
	
	public UasServiceImpl() {
		uasDao = new UasDaoImpl();
	}

	@Override
	public ArrayList<String> getProgramsScheduled() throws UniversityException 
	{
		return uasDao.getProgramsScheduled();
	}

	@Override
	public int setNewApplicant(ApplicantBean app) throws UniversityException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int addProgramsOffered(AdministratorBean admin)
			throws UniversityException {
		// TODO Auto-generated method stub
		return uasDao.addProgramsOffered(admin);
	}

	@Override
	public int updateProgramsOffered(AdministratorBean admin)
			throws UniversityException {
		// TODO Auto-generated method stub
		return uasDao.updateProgramsOffered(admin);
	}

	@Override
	public int deleteProgramsOffered(String admin)
			throws UniversityException {
		// TODO Auto-generated method stub
		return uasDao.deleteProgramsOffered(admin);
	}

	@Override
	public ArrayList<UsersBean> loginAdmin(String user)
			throws UniversityException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean matchCredentials(String lgnid, String pswd, String roles)
			throws UniversityException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int deleteProgramsOffered(int admin) throws UniversityException {
		// TODO Auto-generated method stub
		return 0;
	}
	
	@Override
	public boolean isValid(AdministratorBean applicant)
			throws UniversityException {
		
		String pname = applicant.getProgramName();
		String desc = applicant.getDescription();
		String eli = applicant.getEligibility();
		int dur = applicant.getDuration();
		String doc = applicant.getDegreeCertOffered();
		
		String nameRegex = "[A-Z][a-z]+";
		String doc1 = "Yes";
		String doc2 = "No";
		String eliRegex = "^[1-9][0-9]?$|^100$";
		
		if( !Pattern.matches(nameRegex, pname) ) {
			throw new UniversityException("Program Name Should Start With Capital (For Eg: Java)");
			
		}
		else if( !Pattern.matches(eliRegex, eli) ) {
			throw new UniversityException("It Should Be Between 0 To 100");
		}

		else if( dur<0 ) {
			throw new UniversityException("Please Enter A Valid Positive Duration");
		}
		else if( !(doc.equals("Yes") ) &&  !(doc.equals("No")) ) {
			throw new UniversityException("Stream should be either Yes Or No");
		}

		else  
		{
			return true;
		}
		
		
	}
	
	

}
