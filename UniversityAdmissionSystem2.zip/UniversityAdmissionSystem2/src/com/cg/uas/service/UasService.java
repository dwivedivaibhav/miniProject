package com.cg.uas.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsScheduled;
import com.cg.uas.bean.Users;
import com.cg.uas.exception.UniversityException;

public interface UasService {

	public HashMap<String,String> getProgramsScheduled() throws UniversityException;
	public int setNewApplicant(ApplicantBean app) throws UniversityException;
	public Users getUserCredentials(String user) throws UniversityException;
	public ApplicantBean getProgramsScheduled(String progId) throws UniversityException;
	
	public boolean validateMacUser(String id, String password, String role) throws UniversityException;

}
