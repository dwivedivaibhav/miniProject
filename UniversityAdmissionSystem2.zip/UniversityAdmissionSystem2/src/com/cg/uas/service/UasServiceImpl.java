package com.cg.uas.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsOffered;
import com.cg.uas.bean.ProgramsScheduled;
import com.cg.uas.bean.Users;
import com.cg.uas.dao.UasDao;
import com.cg.uas.dao.UasDaoImpl;
import com.cg.uas.exception.UniversityException;

public class UasServiceImpl implements UasService{

	UasDao uasDao = null;
	Users users = null;
	public UasServiceImpl() {
		uasDao = new UasDaoImpl();
		users = new Users();
	}
	@Override
	public HashMap<String,String> getProgramsScheduled() throws UniversityException {
		
		return uasDao.getProgramsScheduled();
	}
	@Override
	public int setNewApplicant(ApplicantBean app) throws UniversityException {
		
		return uasDao.setNewApplicant(app);
	}
	@Override
	public Users getUserCredentials(String user) throws UniversityException {
		
		return uasDao.getUserCredentials(user);
	}
	//validating mac credentials from db
	@Override
	public boolean validateUser(String id, String password, String user) throws UniversityException {
		
		users = uasDao.getUserCredentials(user);
		
		if(users.getLoginId().equals(id) && users.getPassword().equals(password)) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
	@Override
	public ArrayList<ApplicantBean> getApplicants(String column,String progId) throws UniversityException {
		return uasDao.getApplicants(column, progId);
	}
	@Override
	public int updateApplicationDetails(int appId, String status, LocalDate date)
			throws UniversityException {
		
		return uasDao.updateApplicationDetails(appId, status, date);
	}
	@Override
	public boolean Status(String status) throws UniversityException {
		if(status.equals("applied") || status.equals("Applied")){
			return true;
		}
		else if(status.equals("accepted") || status.equals("Accepted")){
			return true;
		}
		return false;
	}
	/*
	 * Shweta
	 * 
	 */
	@Override
	public int addProgramScheduled(ProgramsScheduled ps)
			throws UniversityException {
		
		return uasDao.addProgramScheduled(ps);
	}
	@Override
	public int deleteProgramScheduled(int scheduledProgId)
			throws UniversityException {
		
		return uasDao.deleteProgramScheduled(scheduledProgId);
	}
	/*
	 * 
	 * vaibhav
	 */
	@Override
	public int addProgramsOffered(ProgramsOffered admin)
			throws UniversityException {
		
		return uasDao.addProgramsOffered(admin);
	}
	@Override
	public int updateProgramsOffered(ProgramsOffered admin)
			throws UniversityException {
		
		return uasDao.updateProgramsOffered(admin);
	}
	@Override
	public int deleteProgramsOffered(String id) throws UniversityException {
		// TODO Auto-generated method stub
		return uasDao.deleteProgramsOffered(id);
	}

}
