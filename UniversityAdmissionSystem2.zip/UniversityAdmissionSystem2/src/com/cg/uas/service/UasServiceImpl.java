package com.cg.uas.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsScheduled;
import com.cg.uas.bean.Users;
import com.cg.uas.dao.UasDao;
import com.cg.uas.dao.UasDaoImpl;
import com.cg.uas.exception.UniversityException;

public class UasServiceImpl implements UasService{

	UasDao uasDao = null;
	Users users = null;
	public UasServiceImpl() {
		uasDao = new UasDaoImpl();
		users = new Users();
	}
	@Override
	public HashMap<String,String> getProgramsScheduled() throws UniversityException {
		
		return uasDao.getProgramsScheduled();
	}
	@Override
	public int setNewApplicant(ApplicantBean app) throws UniversityException {
		
		return uasDao.setNewApplicant(app);
	}
	@Override
	public Users getUserCredentials(String user) throws UniversityException {
		
		return uasDao.getUserCredentials(user);
	}
	//validating mac credentials from db
	@Override
	public boolean validateUser(String id, String password, String user) throws UniversityException {
		
		users = uasDao.getUserCredentials(user);
		
		if(users.getLoginId().equals(id) && users.getPassword().equals(password)) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
	@Override
	public ArrayList<ApplicantBean> getApplicants(String column,String progId) throws UniversityException {
		
		return uasDao.getApplicants(column, progId);
	}
	@Override
	public int updateApplicationDetails(int appId, String status, LocalDate date)
			throws UniversityException {
		
		return uasDao.updateApplicationDetails(appId, status, date);
	}

}
