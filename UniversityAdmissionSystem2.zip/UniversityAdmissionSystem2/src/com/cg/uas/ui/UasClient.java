package com.cg.uas.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsScheduled;
import com.cg.uas.bean.Users;
import com.cg.uas.exception.UniversityException;
import com.cg.uas.service.UasService;
import com.cg.uas.service.UasServiceImpl;

public class UasClient {

	static Scanner sc = null;
	static UasService uasSer= null;
	static ApplicantBean appBean = null;
	static Users users = null;
	static ProgramsScheduled progSch = null;
	
	public static void main(String [] args){
		
		sc = new Scanner(System.in);
		uasSer = new UasServiceImpl();
		users = new Users();
		progSch = new ProgramsScheduled();
		
		while(true) {
			System.out.println("**************************");
			System.out.println("University Admission System");
			System.out.println("**************************");
			
			int choice = 0;
			System.out.println("1. New Application");
			System.out.println("2. Mac");
			System.out.println("3. Administrator");
			System.out.println("4. Exit");
			System.out.println("Enter your choice");
			
			choice = sc.nextInt();
			
			switch(choice) {
			case 1: newApplicant();
			break;
			case 2: mac("mac");
			break;
			case 3: admin("admin");
			break;
			case 4: exit();
			break;
			default:
				System.out.println("Invalid Input");
			}
		}
	}

	private static void newApplicant() {
		int choice = 0;
		
		System.out.println("Program Scheduled");
		HashMap<String,String> progList = new HashMap<String, String>();
		
		try {
			int i = 0;
			progList = uasSer.getProgramsScheduled();
			String scheduledId[] = new String[progList.size()+1];
			for(Map.Entry m:progList.entrySet()) {  
				scheduledId[i] = (String) m.getKey();
				 System.out.println(++i +" "+ m.getValue());  
			}  
			
			System.out.println("Enter your choice");
			choice = sc.nextInt();
			System.out.println(scheduledId[choice-1]);
			setApplicationBean(scheduledId[choice-1]);
		}
		catch (UniversityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private static void setApplicationBean(String scheduledId) {
		
		System.out.println("Enter your Full Name");
		String name = sc.next();
		sc.nextLine();
		System.out.println("Enter Date of Birth in format yyyy-mm-dd");
		String date = sc.next();
		System.out.println("Enter Highest Qualification");
		String qua = sc.next();
		System.out.println("Enter Marks Obtained");
		Float marks = sc.nextFloat();
		System.out.println("Enter Goals");
		String goals = sc.next();
		System.out.println("Enter Email Id");
		String email = sc.next();
		
		String status = "Applied";
		String interviewDate = null;
		
//		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
//		Date date2=null;
//		date2 = dateFormat.parse(date);
		
		LocalDate dob = LocalDate.parse(date);
		
		appBean = new ApplicantBean();
		appBean.setFullName(name);
		appBean.setDateOfBirth(dob);
		appBean.setQualification(qua);
		appBean.setMarks(marks);
		appBean.setGoals(goals);
		appBean.setEmail(email);
		appBean.setStatus(status);
		appBean.setScheduledProgId(scheduledId);
		
		
		try {
			int applicantId = uasSer.setNewApplicant(appBean);
			if(applicantId > 0) {
				System.out.println("Thank You "+name + " for registering to our programs. You unique id is "+ applicantId);
			}
		}
		catch (UniversityException e) {
			System.out.println(e.getMessage());
		}
		
	}

	private static void mac(String user) {
		System.out.println("Enter Login Id:");
		String loginId = sc.next();
		System.out.println("Enter Password: ");
		String password = sc.next();
		
		try {
			
			if(uasSer.validateMacUser(loginId, password, user)) {
				System.out.println("******************************");
				System.out.println("1. View Applications");
				System.out.println("2. Filter Applicants");
				System.out.println("3. Go Back");
				
				int choice = sc.nextInt();
				switch(choice) {
				case 1: viewApplications();
				break;
				case 2: filterApplicant();
				break;
				default: System.out.println("Invalid Input!");
				break;
				}	
				
			}
			else {
				System.out.println("Credentials Fails");
			}
		}
		catch (UniversityException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	}

	private static void viewApplications() {
		
		System.out.println("Enter Program Scheduled Id");
		String pgId = sc.next();
		
		try {
			appBean = uasSer.getProgramsScheduled(pgId);
			System.out.println(appBean);
			System.out.println(appBean.getAppId() + " " + appBean.getFullName() + " " + appBean.getStatus());
		}
		catch (UniversityException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	}

	private static void filterApplicant() {
		
		
	}

	private static void admin(String user) {
		// TODO Auto-generated method stub
		
	}

	private static void exit() {
		// TODO Auto-generated method stub
		
	}
}
