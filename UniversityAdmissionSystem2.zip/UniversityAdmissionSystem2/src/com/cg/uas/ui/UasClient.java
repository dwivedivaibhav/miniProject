package com.cg.uas.ui;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsOffered;
import com.cg.uas.bean.ProgramsScheduled;
import com.cg.uas.bean.Users;
import com.cg.uas.exception.UniversityException;
import com.cg.uas.service.UasService;
import com.cg.uas.service.UasServiceImpl;

public class UasClient {

	static Scanner sc = null;
	static UasService uasSer= null;
	static ApplicantBean appBean = null;
	static Users users = null;
	static ProgramsScheduled progSch = null;

	public static void main(String [] args){

		sc = new Scanner(System.in);
		uasSer = new UasServiceImpl();
		users = new Users();
		progSch = new ProgramsScheduled();

		while(true) {
			System.out.println("**************************");
			System.out.println("University Admission System");
			System.out.println("**************************");

			int choice = 0;
			System.out.println("1. Applicant");
			System.out.println("2. Mac");
			System.out.println("3. Administrator");
			System.out.println("4. Exit");
			System.out.println("Enter your choice");

			choice = sc.nextInt();

			switch(choice) {
			case 1: Applicant();
			break;
			case 2: mac("mac");
			break;
			case 3: admin("admin");
			break;
			case 4: exit();
			break;
			default:
				System.out.println("Invalid Input");
			}
		}
	}

	private static void Applicant() {
		System.out.println("********************************");
		System.out.println("1. New Application");
		System.out.println("2. View Status");
		System.out.println("3. Go Back");
		System.out.println("Enter your choice");
		int choice = sc.nextInt();

		switch(choice){
		case 1: newApplicant();
		break;
		case 2: viewStatus();
		break;		
		}
		//		System.out.println("Program Scheduled");
		//		HashMap<String,String> progList = new HashMap<String, String>();
		//
		//		try {
		//			int i = 0;
		//			progList = uasSer.getProgramsScheduled();
		//			String scheduledId[] = new String[progList.size()+1];
		//			for(Map.Entry m:progList.entrySet()) {  
		//				scheduledId[i] = (String) m.getKey();
		//				System.out.println(++i +" "+ m.getValue());  
		//			}  
		//
		//			System.out.println("Enter your choice");
		//			choice = sc.nextInt();
		//			System.out.println(scheduledId[choice-1]);
		//			setApplicationBean(scheduledId[choice-1]);
		//		}
		//		catch (UniversityException e) {
		//			// TODO Auto-generated catch block
		//			e.printStackTrace();
		//		}

	}

	private static void newApplicant() {
		System.out.println("Program Scheduled");
		HashMap<String,String> progList = new HashMap<String, String>();

		try {
			int i = 0, choice = 0;
			progList = uasSer.getProgramsScheduled();
			String scheduledId[] = new String[progList.size()+1];
			for(Map.Entry m:progList.entrySet()) {  
				scheduledId[i] = (String) m.getKey();
				System.out.println(++i +" "+ m.getValue());  
			}  

			System.out.println("Enter your choice");
			choice = sc.nextInt();
			System.out.println(scheduledId[choice-1]);
			setApplicationBean(scheduledId[choice-1]);
		}
		catch (UniversityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static void viewStatus() {

		ArrayList<ApplicantBean> applicantList = new ArrayList<ApplicantBean>();
		Iterator it = null;

		try {

			System.out.println("Enter Application Id");
			String appId = sc.next();

			//getting applicant based on applicant id
			applicantList = uasSer.getApplicants("application_id", appId);

			it = applicantList.iterator();

			while(it.hasNext()) {
				appBean = (ApplicantBean) it.next();
				System.out.println("Applicant Id: " + appBean.getAppId());
				System.out.println("Applicant Name: " + appBean.getFullName());
				System.out.println("Scheduled Program Id: " + appBean.getScheduledProgId());
				System.out.println("Applicant Status: "  +appBean.getStatus());

				if(appBean.getInterviewDate() != null){
					System.out.println("Interview Date: " + appBean.getInterviewDate());
				}
				else{
					System.out.println("Interview Date: " + appBean.getIdate());
				}

			}
		}
		catch (UniversityException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}

	}

	private static void setApplicationBean(String scheduledId) {

		System.out.println("Enter your Full Name");
		String name = sc.next();
		sc.nextLine();
		System.out.println("Enter Date of Birth in format yyyy-mm-dd");
		String date = sc.next();
		System.out.println("Enter Highest Qualification");
		String qua = sc.next();
		System.out.println("Enter Marks Obtained");
		Float marks = sc.nextFloat();
		System.out.println("Enter Goals");
		String goals = sc.next();
		System.out.println("Enter Email Id");
		String email = sc.next();

		String status = "Applied";
		String interviewDate = null;

		//		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		//		Date date2=null;
		//		date2 = dateFormat.parse(date);

		LocalDate dob = LocalDate.parse(date);

		appBean = new ApplicantBean();
		appBean.setFullName(name);
		appBean.setDateOfBirth(dob);
		appBean.setQualification(qua);
		appBean.setMarks(marks);
		appBean.setGoals(goals);
		appBean.setEmail(email);
		appBean.setStatus(status);
		appBean.setScheduledProgId(scheduledId);


		try {
			int applicantId = uasSer.setNewApplicant(appBean);
			if(applicantId > 0) {
				System.out.println("Thank You "+name + " for registering to our programs. You unique id is "+ applicantId);
			}
		}
		catch (UniversityException e) {
			System.out.println(e.getMessage());
		}

	}

	private static void mac(String user) {
		System.out.println("Enter Login Id:");
		String loginId = sc.next();
		System.out.println("Enter Password: ");
		String password = sc.next();

		try {

			if(uasSer.validateUser(loginId, password, user)) {
				System.out.println("******************************");
				System.out.println("1. View Applications");
				System.out.println("2. Filter Applicants");
				System.out.println("3. Go Back");

				int choice = sc.nextInt();
				switch(choice) {
				case 1: viewApplications();
				break;
				case 2: filterApplicant();
				break;
				default: System.out.println("Invalid Input!");
				break;
				}	

			}
			else {
				System.out.println("Credentials Fails");
			}
		}
		catch (UniversityException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}

	}

	private static void viewApplications() {

		System.out.println("Enter Program Scheduled Id");
		String pgId = sc.next();
		ArrayList<ApplicantBean> applicantList = new ArrayList<ApplicantBean>();

		try {
			//getting applicant based on scheduled_program_id

			applicantList = uasSer.getApplicants("scheduled_program_id", pgId);
			if(applicantList != null) {
				Iterator it = applicantList.iterator();

				while(it.hasNext()) {
					appBean = (ApplicantBean) it.next();
					System.out.println("Applicant Id: " + appBean.getAppId());
					System.out.println("Applicant Name: " + appBean.getFullName());
					System.out.println("Scheduled Program Name: " + appBean.getProgramName());
					System.out.println("Applicant Status: "  +appBean.getStatus());

					//System.out.println("************"+appBean.getInterviewDate());

					if(appBean.getInterviewDate() != null){
						System.out.println("Interview Date: " + appBean.getInterviewDate());
					}
					else{
						System.out.println("Interview Date: " + appBean.getIdate());
					}
					System.out.println("*********************************************");
				}
			}
			else{
				System.err.println("Invalid Id!");
			}
		}
		catch (UniversityException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}

	}

	private static void filterApplicant() {

		ArrayList<ApplicantBean> applicantList = new ArrayList<ApplicantBean>();
		Iterator it = null;

		try {

			System.out.println("Enter applicant id to update the details of applicant");
			String appId = sc.next();

			//getting applicant based on applicant id
			applicantList = uasSer.getApplicants("application_id", appId);
			it = applicantList.iterator();

			while(it.hasNext()) {
				appBean = (ApplicantBean) it.next();
				System.out.println("Applicant Name: " + appBean.getFullName());
				System.out.println("Scheduled Program Name: " + appBean.getProgramName());
				System.out.println("Applicant Status: "  +appBean.getStatus());

				if(appBean.getInterviewDate() != null){
					System.out.println("Interview Date: " + appBean.getInterviewDate());
				}
				else{
					System.out.println("Interview Date: " + appBean.getIdate());
				}

			}
			System.out.println("********************************");

			if(appBean.getStatus().equals("applied") || appBean.getStatus().equals("Applied")){
				updateApplicantSatus("Accepted",appId, appBean.getInterviewDate());
			}
			else if(appBean.getStatus().equals("Accepted") || appBean.getStatus().equals("accepted")){	
				updateApplicantSatus("Confirmed",appId, appBean.getInterviewDate());
			}
			else{
				System.out.println("Pleased to help you");
			}

		}
		catch (UniversityException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}

	}

	private static void updateApplicantSatus(String status, String appId, LocalDate dit) {
		
		if(status.equals("Confirmed")){
			//check interview date should be lesser than todays date
			if(LocalDate.now() != dit) {
				System.out.println("Applicant is yet to appear for interview on " + dit);
			}
			else {
				System.out.println("Do you wish to "+ status+ " the applicant?");
				System.out.println("Y/N");
				String ans = sc.next();
				
				if(ans.equals("Y")){
					try {
						int updated = uasSer.updateApplicationDetails(Integer.valueOf(appId), status, dit);
						System.out.println("You have successfully updated the status!");
					}
					catch (UniversityException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else{
					rejectApplicant();
				}

			}
			//System.out.println("You have successfully updated the status!");
		}
		else{//Confirmed
			System.out.println("Do you wish to "+ status+ " the applicant?");
			System.out.println("Y/N");
			String ans = sc.next();
			
			System.out.println("Enter date of interview in format yyyy-mm-dd");
			String date = sc.next();
			LocalDate interview_date = LocalDate.parse(date);
			
			if(ans.equals("Y")){
				try {
					int updated = uasSer.updateApplicationDetails(Integer.valueOf(appId), status, interview_date);
					System.out.println("You have successfully updated the status!");
				}
				catch (UniversityException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else{
				rejectApplicant();
			}
		}
		
//		System.out.println("Do you wish to "+ status+ " the applicant?");
//		System.out.println("Y/N");
//		String ans = sc.next();
//
//		switch (ans) {
//		case "Y":
//				//System.out.println(status);
//				if(status.equals("Confirmed")){
//					//check interview date should be lesser than todays date
//					if(LocalDate.now() == dit) {
//						System.out.println("Applicant has interview today !");
//					}
//					else{
//						int updated;
//						try {
//							updated = uasSer.updateApplicationDetails(Integer.valueOf(appId), status, dit);
//							System.out.println("You have successfully updated the status!");
//						}
//						catch (UniversityException e) {
//							// TODO Auto-generated catch block
//							e.printStackTrace();
//						}
//					}
//					//System.out.println("You have successfully updated the status!");
//				}
//				else{//Confirmed
//					
//					System.out.println("Enter date of interview in format yyyy-mm-dd");
//					String date = sc.next();
//					LocalDate interview_date = LocalDate.parse(date);
//					int updated;
//					try {
//						updated = uasSer.updateApplicationDetails(Integer.valueOf(appId), status, interview_date);
//						System.out.println("You have successfully updated the status!");
//					}
//					catch (UniversityException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//
//				}
//			break;
//
//		case "N":
//					rejectApplicant();
//			break;
//			
//		default:
//			break;
//		}
	
	}

	private static void rejectApplicant() {
		System.out.println("Yu wish to reject the applicant?");
		System.out.println("Y/N");
		String ch = sc.next();
		switch (ch) {
		case "Y":
			System.out.println("You have successfully rejected the applicant!");
			break;
		case "N":
			System.out.println("No action performed!");
			break;
		default:
			break;
		}
		
	}

	private static void admin(String user) {
		System.out.println("Enter Login Id:");
		String loginId = sc.next();
		System.out.println("Enter Password: ");
		String password = sc.next();

		try {

			if(uasSer.validateUser(loginId, password, user)) {
				
				int option=0;
				System.out.println("1. Add Programs Offered");
				System.out.println("2. Update Programs Offered");
				System.out.println("3. Delete Programs Offered");
				
				System.out.println("4. Add Programs Schedules");
				System.out.println("5. Delete Programs Schedules");
				System.out.println("6. Exit");
				
				System.out.println("Enter your option");
				option = sc.nextInt();
				
				switch(option)
				{
					case 1: addProgramsOffered();
					break;
					case 2: updateProgramsOffered();
					break;
					case 3: deleteProgramsOffered();
					break;
					
					case 4: addProgramsScheduled();
					break;
					case 5: deleteProgramsScheduled();
					break;
					case 6: exit();
					break;
					default:System.out.println("Invalid Input");
				
				}

			}
			else {
				System.out.println("Credentials Fails");
			}


		}
		catch (UniversityException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}

	}

	private static void addProgramsOffered() {
		System.out.println("Enter Program Name : ");
		String pname = sc.next();
		
		System.out.println("Enter Description : ");
		String pdesc = sc.next();
		
		System.out.println("Enter the eligibilty : ");
		String pelig = sc.next();
		
		System.out.println("Enter the duration : ");
		int pdur = sc.nextInt();
		
		System.out.println("Enter if the certificate "
				+ "is offered of the program : ");
		String pcert = sc.next();
		
		try
		{
			ProgramsOffered adminBean = new ProgramsOffered();
		
			adminBean.setProgramName(pname);
			adminBean.setDescription(pdesc);
			adminBean.setEligibility(pelig);
			adminBean.setDuration(pdur);
			adminBean.setDegreeCertOffered(pcert);
		
			int dataAdded = uasSer.addProgramsOffered(adminBean);
			
			if (dataAdded == 1)
			{
				System.out.println("Programs Added into the Table");
			}
			
			else
			{
				System.out.println("Maybe some error occurred "
						+ "during the addition of the program");
			}
		}
		
		catch (UniversityException ue)
		{
			System.out.println(ue.getMessage());
		}
		
	}

	private static void updateProgramsOffered() {
		
		System.out.println("Enter Program Name You Want To Update: ");
		String programname= sc.next();
		
		System.out.println("Enter Description : ");
		String programdesc = sc.next();
		
		System.out.println("Enter the eligibilty : ");
		String programelig = sc.next();
		
		System.out.println("Enter the duration : ");
		int programdur = sc.nextInt();
		
		System.out.println("Enter if the certificate "
				+ "is offered of the program : ");
		String programcert = sc.next();
		
		try
		{
			ProgramsOffered adminBean = new ProgramsOffered();
		
			adminBean.setProgramName(programname);
			adminBean.setDescription(programdesc);
			adminBean.setEligibility(programelig);
			adminBean.setDuration(programdur);
			adminBean.setDegreeCertOffered(programcert);
		
			int dataUpdated = uasSer.updateProgramsOffered(adminBean);
			
			if (dataUpdated == 1)
			{
				System.out.println("Programs Added into the Table");
			}
			
			else
			{
				System.out.println("Maybe some error occurred "
						+ "during the addition of the program");
			}
		}
		
		catch (UniversityException ue)
		{
			System.out.println(ue.getMessage());
		}
		
		
	}

	private static void deleteProgramsOffered() {
		System.out.println("Enter your Program Name which is to be deleted");
		String admin=sc.next();
		
		try
		{
			int dataDeleted = uasSer.deleteProgramsOffered(admin);
			if(dataDeleted==1)
			{
				System.out.println("Scheduled program deleted");
			}
			else
			{
				System.out.println("Program Name Is Not Present");
			}
			
		} 
		catch (UniversityException e)
		{
			System.out.println(e.getMessage());
			//e.printStackTrace();
		}
		
	}

	private static void addProgramsScheduled() {
		System.out.println("Enter program name:");
		String pname = sc.next();
		System.out.println("Enter location:");
		String loc = sc.next();
		System.out.println("Enter start date:");
		String sdate = sc.next();
		System.out.println("Enter end date:");
		String edate = sc.next();
		System.out.println("Enter session per week:");
		int session = sc.nextInt();
		
		LocalDate startDate=LocalDate.parse(sdate);
		
		LocalDate endDate=LocalDate.parse(edate);
		
		ProgramsScheduled ps = new ProgramsScheduled(pname,loc,startDate,endDate,session);
		try {
			int id1=uasSer.addProgramScheduled(ps);
			if(id1>0)
			{
				System.out.println("Data successfully added");
			}
		}
		catch (UniversityException e) {
			System.out.println(e.getMessage());
		}
	}
		
	

	private static void deleteProgramsScheduled() {
		System.out.println("Enter ur id which is to be deleted");
		int sid=sc.nextInt();
		
		try
		{
			int dataDeleted = uasSer.deleteProgramScheduled(sid);
			if(dataDeleted==1)
			{
				System.out.println("Scheduled program id deleted");
			}
			else
			{
				System.out.println("may have some exception deletion");
			}
			
		} 
		catch (UniversityException e)
		{
			System.out.println(e.getMessage());
			//e.printStackTrace();
		}
		
	}

	private static void exit() {
		// TODO Auto-generated method stub

	}
}
