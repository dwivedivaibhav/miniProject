package com.cg.uas.bean;

public class Users {

	private String loginId;
	public Users() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Users(String loginId, String password) {
		super();
		this.loginId = loginId;
		this.password = password;
	}
	@Override
	public String toString() {
		return "Users [loginId=" + loginId + ", password=" + password + "]";
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	private String password;
	
}
