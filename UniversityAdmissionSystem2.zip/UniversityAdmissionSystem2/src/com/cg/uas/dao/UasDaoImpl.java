package com.cg.uas.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsOffered;
import com.cg.uas.bean.ProgramsScheduled;
import com.cg.uas.bean.Users;
import com.cg.uas.exception.UniversityException;
import com.cg.uas.util.DBUtil;

public class UasDaoImpl implements UasDao {

	Connection conn = null;
	PreparedStatement pst = null;
	Statement st = null;
	ResultSet rs = null;

	//returns programs_scheduled record
	@Override
	public HashMap<String,String> getProgramsScheduled() throws UniversityException {

		String selProgSch = "SELECT * FROM programs_scheduled";
		HashMap<String,String> progSchList = new HashMap<String, String>();

		try {

			conn = DBUtil.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(selProgSch);

			while(rs.next()) {

				progSchList.put(rs.getString(1),rs.getString(2));
				

			}
		} 
		catch (Exception e) {
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				st.close();
				rs.close();
			}
			catch(Exception e){
				throw new UniversityException(e.getMessage());
			}
		}

		return progSchList;
	}

	//inserting new applicant
	@Override
	public int setNewApplicant(ApplicantBean app) throws UniversityException {
		String insQry = "INSERT INTO application(application_id, full_name, date_of_birth,highest_qualification,"
				+ "marks_obtained,goals,email_id, scheduled_program_id, status) values(?,?,?,?,?,?,?,?,?)";
		int id = 0;
		try {
			conn = DBUtil.getConnection();
			st = conn.createStatement();
			pst = conn.prepareStatement(insQry);
			id = generateAppId();
			pst.setInt(1, id);
			pst.setString(2, app.getFullName());
			pst.setDate(3, Date.valueOf(app.getDateOfBirth()));
			pst.setString(4, app.getQualification());
			pst.setFloat(5, app.getMarks());
			pst.setString(6, app.getGoals());
			pst.setString(7, app.getEmail());
			pst.setString(8, app.getScheduledProgId());
			pst.setString(9, app.getStatus());
			
			
			pst.executeUpdate();
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				st.close();
				rs.close();
			}
			catch(Exception e){
				throw new UniversityException(e.getMessage());
			}
		}

		return id;
	}

	private int generateAppId() throws UniversityException {
		String qry = "SELECT application_id_seq.NEXTVAL FROM DUAL";
		int generateValue;
		
		try {
			conn = DBUtil.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(qry);
			
			rs.next();
			generateValue = rs.getInt(1);
		} 
		catch (Exception e) {
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				st.close();
				rs.close();
			}
			catch(Exception e){
				throw new UniversityException(e.getMessage());
			}
		}

		return generateValue;
	}

	@Override
	public Users getUserCredentials(String user) throws UniversityException {
		String selQry = "SELECT * FROM users WHERE role=?";
		
		Users users = null;;
		try {
		
			conn = DBUtil.getConnection();
			pst = conn.prepareStatement(selQry);
			pst.setString(1, user);
			rs = pst.executeQuery();
			
			while(rs.next()) {
				users = new Users(rs.getString(1), rs.getString(2));
			}
		}
		catch (Exception e) {
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				pst.close();
				rs.close();
			}
			catch(Exception e){
				
				throw new UniversityException(e.getMessage());
			}
		}
		return users;
	}

	@Override
	public ArrayList<ApplicantBean> getApplicants(String column,String progId) throws UniversityException {
		String qry = "SELECT application_id,full_name,status,date_of_interview,program_name FROM application a, programs_scheduled p WHERE a.scheduled_program_id=p.scheduled_program_id and a."+column+"=?";
		int appId = 0;
		ArrayList<ApplicantBean> applicantList = new ArrayList<ApplicantBean>();
		ApplicantBean appBean = null;
		//System.out.println(column + progId + appId);
		try {
			conn = DBUtil.getConnection();
			pst =conn.prepareStatement(qry);
			//pst.setString(1, column);
			
			if(column.equals("application_id")){ //getting applicant id based on application id 
				appId = Integer.valueOf(progId);
				pst.setInt(1, appId);
			}
			else{//getting applicant id based on scheduled program id 
				pst.setString(1, progId);
			}
			
			rs = pst.executeQuery();
			
			while(rs.next()) {
				
				String d = rs.getString("date_of_interview");//for handling null values
				//System.out.println("rs is: "+rs + " name: " + d);
				if(rs.wasNull()){
					//System.out.println("Name :"+rs.getString("program_name"));
					appBean = new ApplicantBean();
					
					appBean.setAppId(rs.getInt(1));
					appBean.setFullName(rs.getString(2));
					appBean.setProgramName(rs.getString("program_name"));
					appBean.setStatus(rs.getString("status"));
					appBean.setIdate("Not Assigned yet");
					
					applicantList.add(appBean);
					
				}
				else{

					appBean = new ApplicantBean();
					
					appBean.setAppId(rs.getInt(1));
					appBean.setFullName(rs.getString(2));
					appBean.setProgramName(rs.getString("program_name"));
					appBean.setStatus(rs.getString("status"));
					appBean.setInterviewDate(rs.getDate("date_of_interview").toLocalDate());
					
					applicantList.add(appBean);
				}
				
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new UniversityException("Invalid Id!");
		}
		finally{

			try{
				conn.close();
				pst.close();
				rs.close();
			}
			catch(Exception e){
				
				throw new UniversityException(e.getMessage());
			}
		}
		
		return applicantList;
	}

	@Override
	public int updateApplicationDetails(int appId, String status, LocalDate date)
			throws UniversityException {
		String qry = "update application set status=? , date_of_interview=? where application_id=?";
		int updated = 0;
		try {
			conn = DBUtil.getConnection();
			pst = conn.prepareStatement(qry);
			pst.setString(1, status);
			pst.setDate(2, Date.valueOf(date));
			pst.setInt(3, appId);
			
			updated = pst.executeUpdate();
			
		} 
		catch (Exception e) {
			
			throw new UniversityException(e.getMessage());
		}
		
		return updated;
	}
	
	/*
	 * Shweta
	 * 
	 */
	
	@Override
	public int addProgramScheduled(ProgramsScheduled ps)
			throws UniversityException {
		String addQry = "INSERT INTO Programs_Scheduled values(?,?,?,?,?,?)";
		int dataAdd = 0;
		try {
			conn = DBUtil.getConnection();
			pst = conn.prepareStatement(addQry);
			
			LocalDate startDate=ps.getStartDate();
			Date sDate=Date.valueOf(startDate);
			LocalDate endDate=ps.getEndDate();
			Date eDate=Date.valueOf(endDate);
			
			pst.setInt(1,generateScheduledProgId());
			pst.setString(2, ps.getProgramName());
			pst.setString(3, ps.getLocation());
			pst.setDate(4, sDate);
			pst.setDate(5, eDate);
			pst.setInt(6, ps.getSessionPerWeek());
			
			
			dataAdd = pst.executeUpdate();
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new UniversityException("First program should be offered.");
		}
		finally{

			try{
				conn.close();
				st.close();
				rs.close();
			}
			catch(Exception e){
				throw new UniversityException("First program should be offered.");
			}
		}

		return dataAdd;
	}

	private int generateScheduledProgId() throws UniversityException {
		String qry = "SELECT SCHEDULED_PGM_SEQ.NEXTVAL FROM DUAL";
		int generateValued;
		
		try {
			conn = DBUtil.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(qry);
			
			rs.next();
			generateValued = rs.getInt(1);
		} 
		catch (Exception e) {
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				st.close();
				rs.close();
			}
			catch(Exception e){
				throw new UniversityException(e.getMessage());
			}
		}

		return generateValued;
	}

	@Override
	public int deleteProgramScheduled(int scheduledProgId)
			throws UniversityException {
		String deleteQry="delete from Programs_Scheduled where scheduled_program_id=?";
		int dataDeleted=0;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(deleteQry);
			pst.setInt(1,scheduledProgId);
			dataDeleted=pst.executeUpdate();
			
		} 
		
		catch (Exception e)
		{
			throw new UniversityException(e.getMessage());
		
		} 
		finally
		{
			try {
				pst.close();
				conn.close();
			} 
			catch (SQLException e) 
			{
				throw new UniversityException(e.getMessage());
				
			}
			
		}
		
		return dataDeleted;
		
	}
	/*
	 * 
	 * vaibhav
	 * 
	 */
	@Override
	public int addProgramsOffered(ProgramsOffered admin)
			throws UniversityException {
		String insertQry = "insert into Programs_Offered"
				+ "(program_name, description, applicant_eligibility, duration, "
				+ "degree_certificate_offered) values(?, ?, ?, ?, ?)";
		
		int dataAdded = 0;
		try
		{
			conn = DBUtil.getConnection();
			pst = conn.prepareStatement(insertQry);
			pst.setString(1, admin.getProgramName());
			pst.setString(2, admin.getDescription());
			pst.setString(3, admin.getEligibility());
			pst.setInt(4, admin.getDuration());
			pst.setString(5, admin.getDegreeCertOffered());
			dataAdded = pst.executeUpdate();
			
//			System.out.println("Program Inserted into the Table"
//					+ " Programs Offered");
		}
		catch (Exception e)
		{
			throw new UniversityException(e.getMessage());
		}
		
		finally
		{
			try
			{
				conn.close();
				pst.close();
			}
			catch (SQLException se)
			{
				throw new UniversityException(se.getMessage());
			}
		}
		
		return dataAdded;
	}

	@Override
	public int updateProgramsOffered(ProgramsOffered admin)
			throws UniversityException {
		String qry = "update Programs_Offered set description=?,"
				+ "applicant_eligibility=?, duration=?, "
				+ "degree_certificate_offered=?"
				+ " where program_name=?";
		
		int dataUpdated = 0;
		//AdministratorBean admin1=new AdministratorBean();		
		try
		{
			conn = DBUtil.getConnection();
			pst = conn.prepareStatement(qry);
			pst.setString(1, admin.getDescription());
			pst.setString(2, admin.getEligibility());
			pst.setInt(3, admin.getDuration());
			pst.setString(4, admin.getDegreeCertOffered());
			pst.setString(5, admin.getProgramName());
			
			dataUpdated = pst.executeUpdate();
//			System.out.println("Programs offered Table is updated");
		}
		catch (Exception e)
		{
			throw new UniversityException(e.getMessage());
		}
		finally
		{
			try {
				conn.close();
				pst.close();
			} 
			catch (SQLException se) {
				// TODO: handle exception	
				throw new UniversityException(se.getMessage());
			}
		}
		
		return dataUpdated;
	}

	@Override
	public int deleteProgramsOffered(String id) throws UniversityException {
		String qry = "Delete from Programs_Offered where program_name = ?";
		
		int dataDeleted = 0;
		try
		{
			conn = DBUtil.getConnection();
			pst = conn.prepareStatement(qry);
			pst.setString(1, id);
			dataDeleted = pst.executeUpdate();
			
		}
		catch (Exception e)
		{
			throw new UniversityException(e.getMessage());
		}
		finally
		{
			try
			{
				conn.close();
				pst.close();
			}
			
			catch (SQLException se)
			{
				throw new UniversityException(se.getMessage());
			}
		}
		return dataDeleted;
	}

}
