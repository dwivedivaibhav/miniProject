package com.cg.uas.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsScheduled;
import com.cg.uas.bean.Users;
import com.cg.uas.exception.UniversityException;
import com.cg.uas.util.DBUtil;

public class UasDaoImpl implements UasDao {

	Connection conn = null;
	PreparedStatement pst = null;
	Statement st = null;
	ResultSet rs = null;

	//returns programs_scheduled record
	@Override
	public HashMap<String,String> getProgramsScheduled() throws UniversityException {

		String selProgSch = "SELECT * FROM programs_scheduled";
		HashMap<String,String> progSchList = new HashMap<String, String>();

		try {

			conn = DBUtil.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(selProgSch);

			while(rs.next()) {

				progSchList.put(rs.getString(1),rs.getString(2));
				

			}
		} 
		catch (Exception e) {
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				st.close();
				rs.close();
			}
			catch(Exception e){
				throw new UniversityException(e.getMessage());
			}
		}

		return progSchList;
	}

	//inserting new applicant
	@Override
	public int setNewApplicant(ApplicantBean app) throws UniversityException {
		String insQry = "INSERT INTO application(application_id, full_name, date_of_birth,highest_qualification,"
				+ "marks_obtained,goals,email_id, scheduled_program_id, status) values(?,?,?,?,?,?,?,?,?)";
		int id = 0;
		try {
			conn = DBUtil.getConnection();
			st = conn.createStatement();
			pst = conn.prepareStatement(insQry);
			id = generateAppId();
			pst.setInt(1, id);
			pst.setString(2, app.getFullName());
			pst.setDate(3, Date.valueOf(app.getDateOfBirth()));
			pst.setString(4, app.getQualification());
			pst.setFloat(5, app.getMarks());
			pst.setString(6, app.getGoals());
			pst.setString(7, app.getEmail());
			pst.setString(8, app.getScheduledProgId());
			pst.setString(9, app.getStatus());
			
			
			pst.executeUpdate();
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				st.close();
				rs.close();
			}
			catch(Exception e){
				throw new UniversityException(e.getMessage());
			}
		}

		return id;
	}

	private int generateAppId() throws UniversityException {
		String qry = "SELECT application_id_seq.NEXTVAL FROM DUAL";
		int generateValue;
		
		try {
			conn = DBUtil.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(qry);
			
			rs.next();
			generateValue = rs.getInt(1);
		} 
		catch (Exception e) {
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				st.close();
				rs.close();
			}
			catch(Exception e){
				throw new UniversityException(e.getMessage());
			}
		}

		return generateValue;
	}

	@Override
	public Users getUserCredentials(String user) throws UniversityException {
		String selQry = "SELECT * FROM users WHERE role=? ";
		
		Users users = null;;
		try {
		
			conn = DBUtil.getConnection();
			pst = conn.prepareStatement(selQry);
			pst.setString(3, user);
			rs = pst.executeQuery();
			
			while(rs.next()) {
				users = new Users(rs.getString(1), rs.getString(2));
			}
		}
		catch (Exception e) {
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				pst.close();
				rs.close();
			}
			catch(Exception e){
				
				throw new UniversityException(e.getMessage());
			}
		}
		return users;
	}

	@Override
	public ApplicantBean getProgramsScheduled(String progId) throws UniversityException {
		String qry = "SELECT * FROM application WHERE scheduled_program_id=?";
		ApplicantBean appBean = null;
		
		try {
			conn = DBUtil.getConnection();
			pst =conn.prepareStatement(qry);
			pst.setString(1, progId);
			
			rs = pst.executeQuery();
			
			while(rs.next()) {
				// need to get all the table columns 
				appBean = new ApplicantBean(rs.getInt(1),rs.getString(2), rs.getString("scheduled_program_id"),
						rs.getString("status"));
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				pst.close();
				rs.close();
			}
			catch(Exception e){
				
				throw new UniversityException(e.getMessage());
			}
		}
		
		return appBean;
	}

}
