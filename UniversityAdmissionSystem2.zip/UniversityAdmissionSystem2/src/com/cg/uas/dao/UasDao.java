package com.cg.uas.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsScheduled;
import com.cg.uas.bean.Users;
import com.cg.uas.exception.UniversityException;

public interface UasDao {
	public HashMap<String,String> getProgramsScheduled() throws UniversityException;
	public int setNewApplicant(ApplicantBean app) throws UniversityException;
	public Users getUserCredentials(String user) throws UniversityException;
	public ArrayList<ApplicantBean> getApplicants(String column,String progId) throws UniversityException;
	public int updateApplicationDetails(int appId, String status, LocalDate date) throws UniversityException;
}
