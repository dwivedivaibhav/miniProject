package com.cg.uas.exception;

public class UniversityException extends Exception {

	public UniversityException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UniversityException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public UniversityException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public UniversityException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UniversityException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
