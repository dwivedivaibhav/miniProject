package com.cg.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.uas.dto.Applicant;
import com.cg.uas.dto.ProgramScheduled;
import com.cg.uas.exception.UniversityException;

@Repository("uasdao")
public class UasDaoImpl implements IUasDao {

	Connection conn = null;
	PreparedStatement pst = null;
	Statement st = null;
	ResultSet rs = null;

	@PersistenceContext
	EntityManager em;

	@Override
	public List<ProgramScheduled> getProgramsScheduled()
			throws UniversityException {

		Query qry;

		try{
			
			qry = em.createQuery("SELECT p FROM ProgramScheduled p");
		}
		catch(Exception e){
			throw new UniversityException("Exception while searching...");
		}

		return qry.getResultList();

	}


	@Override
	public int setNewApplicant(Applicant app) throws UniversityException {
		
		try{
			
			em.persist(app);
			em.flush();

		}
		catch(Exception e){
			e.printStackTrace();
			throw new UniversityException("Insertion Errror");
		}
		return app.getAppId();
	}


	@Override
	public Applicant getApplicant(int id) throws UniversityException {
		Applicant app = null;
		try{
			app = em.find(Applicant.class, id);
		}
		catch(Exception e){
			e.printStackTrace();
			throw new UniversityException("Selection Errror");
		}
		return app;
	}


	@Override
	public String getProgramName(String pid) throws UniversityException {
		
		ProgramScheduled prog = null;
		try{
			
			prog = em.find(ProgramScheduled.class, pid);
		}
		catch(Exception e){
			e.printStackTrace();
			throw new UniversityException("Selection Errror");
		}
		return prog.getProgramName();
	}


//	@Override
//	public List<Applicant> getApplicant(int id) throws UniversityException {
//		
//		Query qry;
//		
//		try{
//			
//			qry = em.createQuery("select a.fullName,a.programStatus,p.programName FROM Applicant a, ProgramScheduled p where "
//					+ "a.programId=p.programId and a.appId=:d");
//			qry.setParameter("d", id);
//		}
//		catch(Exception e){
//			e.printStackTrace();
//			throw new UniversityException("Selection Errror");
//		}
//		
//		return qry.getResultList();
//	}

}
