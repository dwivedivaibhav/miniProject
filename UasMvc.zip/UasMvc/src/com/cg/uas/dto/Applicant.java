package com.cg.uas.dto;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="application")
public class Applicant {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")//generating sequence with name=emp_seq
	@SequenceGenerator(name="seq",sequenceName="APPLICATION_ID_SEQ")
	@Column(name="application_id")
	@NotNull
	private int appId;
	
	@Column(name="full_name")
	@NotEmpty(message="Name Should not be empty")
	private	String fullName;
	
	@Column(name="date_of_birth")
	private Date dateOfBirth;
	
	@Column(name="HIGHEST_QUALIFICATION")
	private String qualification;
	
	@Column(name="MARKS_OBTAINED")
	private int marks;
	
	@Column(name="GOALS")
	private String goals;
	
	@Column(name="EMAIL_ID")
	private String email;
	
	@Column(name="SCHEDULED_PROGRAM_ID")
	private String programId;
	
	
	private String programname;


	public String getProgramname() {
		return programname;
	}

	public void setProgramname(String programname) {
		this.programname = programname;
	}

	public int getAppId() {
		return appId;
	}

	public void setAppId(int appId) {
		this.appId = appId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public String getGoals() {
		return goals;
	}

	public void setGoals(String goals) {
		this.goals = goals;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getProgramId() {
		return programId;
	}

	public void setProgramId(String programId) {
		this.programId = programId;
	}

	public String getProgramStatus() {
		return programStatus;
	}

	public void setProgramStatus(String programStatus) {
		this.programStatus = programStatus;
	}

	public Date getInterviewDate() {
		return interviewDate;
	}

	public void setInterviewDate(Date interviewDate) {
		this.interviewDate = interviewDate;
	}

	@Column(name="status")
	private String programStatus;
	
	@Column(name="date_of_interview")
	private Date interviewDate;


	@Override
	public String toString() {
		return "Applicant [appId=" + appId + ", fullName=" + fullName
				+ ", dateOfBirth=" + dateOfBirth + ", qualification="
				+ qualification + ", marks=" + marks + ", goals=" + goals
				+ ", email=" + email + ", programId=" + programId
				+ ", programname=" + programname + ", programStatus="
				+ programStatus + ", interviewDate=" + interviewDate + "]";
	}


	
}
