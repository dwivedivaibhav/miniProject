package com.cg.uas.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.uas.dto.Applicant;
import com.cg.uas.dto.ProgramScheduled;
import com.cg.uas.exception.UniversityException;
import com.cg.uas.service.IUasService;

@Controller
@Scope("session")
public class UasController {

	@Autowired
	IUasService uasSer;

	//going to home.jsp
	@RequestMapping(value="homeurl", method=RequestMethod.GET)
	public String applicantPage(){
		return "home1";
	}

	@RequestMapping(value="programsurl", method=RequestMethod.GET)
	public ModelAndView programsList(){
		List<ProgramScheduled> plist = new ArrayList<>();
		try {

			plist = uasSer.getProgramsScheduled();
			System.out.println(plist);
		}
		catch (UniversityException e) {

			e.printStackTrace();
		}
		return new ModelAndView("programlist","prog",plist);

	}

	//opeinig application form
	@RequestMapping(value="registerurl", method=RequestMethod.GET)
	public ModelAndView register(@ModelAttribute("reg") Applicant app, @RequestParam("id") String pid, HttpServletRequest request){
		//registerApplicant(new Applicant(), pid);

		System.out.println("getting id from programs Scheduled..." + pid);

		request.getSession(true).setAttribute("pgid", pid);

		return new ModelAndView("register1","pgid",pid);
	}

	//	//after applying for program
	//	@RequestMapping(value="registerapplicanturl", method=RequestMethod.GET)
	//	public String registerApplicant(@RequestParam("name") String name, @RequestParam("dob") String dob,@RequestParam("hq") String hq
	//			, @RequestParam("marks") int marks, @RequestParam("goals") String goals, @RequestParam("email") String email,
	//			@RequestParam("pid") String pid){
	//		Applicant app = new Applicant();
	//		app.setFullName(name);
	//		
	////		LocalDate date = LocalDate.parse(dob);
	////		app.setDateOfBirth(date);
	//		app.setQualification(hq);
	//		app.setEmail(email);
	//		app.setGoals(goals);
	//		app.setMarks(marks);
	//		app.setProgramStatus("Applied");
	//		app.setProgramId(pid);
	//		
	//		try {
	//			int id = uasSer.setNewApplicant(app);
	//			System.out.println("Id....." + id);
	//		}
	//		catch (UniversityException e) {
	//			
	//			e.printStackTrace();
	//		}
	//		
	//		return "";
	//	}


	//after applying for program
	@RequestMapping(value="registerapplicanturl", method=RequestMethod.POST)
	public ModelAndView registerApplicant(@Valid@ModelAttribute("reg") Applicant app, @RequestParam("id") String pid, HttpServletRequest request, BindingResult result){
		int id = 0;

		String id1 = 	(String) request.getSession(false).getAttribute("pgid");
		System.out.println("id...." + id1);
		try {

			if(result.hasErrors()) {
				System.out.println("Inside error");

				return new ModelAndView("registerapplicanturl");
			}
			else{

				System.out.println("no error.....");

				System.out.println("getting id from session..." + pid);
				app.setProgramId(pid);
				app.setProgramStatus("Applied");
				System.out.println(app);
				Date dob = app.getDateOfBirth();

				id = uasSer.setNewApplicant(app);
			}


		}
		catch (UniversityException e) {
			System.out.println(e.getMessage());
		}
		if(id > 0)
		{
			return new ModelAndView("success","app",app);
		}
		else
		{
			return new ModelAndView("faliure","msg","Something went wrong, please try again later!");

		}

	}


	//going to home.jsp
	@RequestMapping(value="viewstatusurl", method=RequestMethod.GET)
	public String idForStatus(@ModelAttribute("view") Applicant app){

		return "inputid";
	}

	@RequestMapping(value="view", method=RequestMethod.POST)
	public ModelAndView viewStatus(@ModelAttribute("view") Applicant app){

		Applicant applist = null;
		try {

			applist = uasSer.getApplicant(app.getAppId());
			if(applist != null) {
				String pname = uasSer.getProgramName(applist.getProgramId());
				applist.setProgramname(pname);
			}

		}
		catch (UniversityException e) {
			return new ModelAndView("faliure","msg","No Record Found!");

		}
		if(applist != null) {
			return new ModelAndView("applicant","a",applist);
		}
		else {
			return new ModelAndView("faliure","msg","No Record Found!");
		}	

	}


}
